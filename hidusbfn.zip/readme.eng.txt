Patch folder dedicated for using with atsiv method.

If you want to automatically apply changes you have to create 
Scheduler task(job) running under admin or system account on 
system startup to run .CMD file like RESTART.CMD
Or manually run it with elevated rigths.

restart.cmd is only example! You need to edit it with your 
real paths and device ids.

"DeviceInstanceID1" and so on is the first line of clipboard
buffer which setup.exe is copied by "Copy IDs" button.
Of course, you can use any other program (like devcon.exe) 
instead of DevState64.exe to restart device.

DevState tool located at
https://github.com/LordOfMice/Tools/devstate.zip
